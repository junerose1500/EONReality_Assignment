$(document).ready(function() {
    // Show Password
    $("#show_hide_password a").on('click', function(event) {
        event.preventDefault();
        if($('#show_hide_password input').attr("type") == "text"){
            $('#show_hide_password input').attr('type', 'password');
            $('#show_hide_password i').addClass( "fa-eye-slash" );
            $('#show_hide_password i').removeClass( "fa-eye" );
        }else if($('#show_hide_password input').attr("type") == "password"){
            $('#show_hide_password input').attr('type', 'text');
            $('#show_hide_password i').removeClass( "fa-eye-slash" );
            $('#show_hide_password i').addClass( "fa-eye" );
        }
    });

    // Placeholder Float
    function updateText(event){
        var input=$(this);
        setTimeout(function(){
          var val=input.val();
          if(val!="")
            input.parent().addClass("floating-placeholder-float");
          else
            input.parent().removeClass("floating-placeholder-float");
        },1)
    }
    $(".form-group input").keydown(updateText);
    $(".form-group input").change(updateText);

    // Validate Form
    $("#login-form").validate({
        rules: {
            email: {
                required: true
            },
            password: {
                required: true
            }
        },
        messages: {
            email: {
                required: "This is required field."
            },
            password: {
                required: "This is required field."
            }
        },
        submitHandler: function (form) { 
            return false;
        }
    });
});